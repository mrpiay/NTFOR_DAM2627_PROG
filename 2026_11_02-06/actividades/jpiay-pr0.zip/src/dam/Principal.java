package dam;

import static dam.Auxiliar.*;

public class Principal {
    public static void main(String[] args) {
        print("Edad?");
        print("Tienes " + getInt() + " años");
    }
}