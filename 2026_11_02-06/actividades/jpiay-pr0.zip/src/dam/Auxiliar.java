package dam;

import java.util.Scanner;

public class Auxiliar {

    public static void print(String texto) {
        System.out.println(texto);
    }
    
    public static int getInt() {
        Scanner teclado = new Scanner(System.in);
        return Integer.parseInt(teclado.nextLine());
    }
    
}
