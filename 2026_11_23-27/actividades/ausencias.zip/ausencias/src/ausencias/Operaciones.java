package ausencias;

// Clase de operaciones: trabaja con los arrays de la clase Datos
// (Datos.estudiantes, Datos.dias y Datos.ausencias)
public class Operaciones {

    // Devuelve la posición del estudiante en Datos.estudiantes, o -1 si no está.
    // No distingue mayúsculas de minúsculas: "ana" encuentra a "Ana".
    static int buscarEstudiante(String nombre) {
        // escribe aquí tu código

        return -1; // cámbialo: está para que el proyecto compile
    }

    // Devuelve la posición del día ("L", "M", "X", "J" o "V") en Datos.dias, o -1 si no está.
    static int buscarDia(String dia) {
        // escribe aquí tu código

        return -1; // cámbialo: está para que el proyecto compile
    }

    // Pone una ausencia al estudiante en ese día.
    // Devuelve true si la pone, y false si el estudiante o el día no existen.
    // Usa buscarEstudiante y buscarDia.
    static boolean ponerAusencia(String nombre, String dia) {
        // escribe aquí tu código

        return false; // cámbialo: está para que el proyecto compile
    }

    // Imprime los estudiantes ausentes en ese día, uno por línea,
    // o «Nadie» si no falta nadie. Si el día no existe, lo dice.
    // Usa buscarDia.
    static void imprimirAusentes(String dia) {
        // escribe aquí tu código

    }

    // Prueba las operaciones. A la derecha, lo que debe salir.
    public static void main(String[] args) {
        // Buscar estudiantes (con los nombres de Datos en este orden:
        // Ana, Brais, Carla, Daniel, Elena, Fran, Iria, Lucas, Noa, Xoán)
        System.out.println("Brais está en la posición " + buscarEstudiante("Brais")); // 1
        System.out.println("noa está en la posición " + buscarEstudiante("noa"));     // 8
        System.out.println("Pepe está en la posición " + buscarEstudiante("Pepe"));   // -1

        // Poner ausencias
        System.out.println(ponerAusencia("Ana", "L"));   // true
        System.out.println(ponerAusencia("Iria", "L"));  // true
        System.out.println(ponerAusencia("Brais", "X")); // true
        System.out.println(ponerAusencia("Pepe", "L"));  // false: Pepe no está
        System.out.println(ponerAusencia("Ana", "S"));   // false: S no es un día

        // Imprimir ausentes
        imprimirAusentes("L"); // Ausentes el L:   Ana   Iria
        imprimirAusentes("X"); // Ausentes el X:   Brais
        imprimirAusentes("V"); // Ausentes el V:   Nadie
        imprimirAusentes("S"); // El día S no existe
    }
}
