package ausencias;

// Clase de operaciones: trabaja con los arrays de la clase Datos
public class Operaciones {

    // Devuelve la posición del estudiante en Datos.estudiantes, o -1 si no está.
    // No distingue mayúsculas de minúsculas: "ana" encuentra a "Ana".
    static int buscarEstudiante(String nombre) {
        for (int e = 0; e < Datos.estudiantes.length; e++) {
            if (Datos.estudiantes[e].equalsIgnoreCase(nombre)) {
                return e;
            }
        }
        return -1;
    }

    // Devuelve la posición del día ("L", "M", "X", "J" o "V") en Datos.dias, o -1 si no está.
    static int buscarDia(String dia) {
        for (int d = 0; d < Datos.dias.length; d++) {
            if (Datos.dias[d].equalsIgnoreCase(dia)) {
                return d;
            }
        }
        return -1;
    }

    // Pone una ausencia al estudiante en ese día.
    // Devuelve true si la pone, y false si el estudiante o el día no existen.
    static boolean ponerAusencia(String nombre, String dia) {
        int e = buscarEstudiante(nombre);
        int d = buscarDia(dia);
        if (e == -1 || d == -1) {
            return false;
        }
        Datos.ausencias[e][d] = true;
        return true;
    }

    // Imprime los estudiantes ausentes en ese día, uno por línea,
    // o «Nadie» si no falta nadie. Si el día no existe, lo dice.
    static void imprimirAusentes(String dia) {
        int d = buscarDia(dia);
        if (d == -1) {
            System.out.println("El día " + dia + " no existe");
            return;
        }
        System.out.println("Ausentes el " + Datos.dias[d] + ":");
        int cuantos = 0;
        for (int e = 0; e < Datos.estudiantes.length; e++) {
            if (Datos.ausencias[e][d]) {
                System.out.println("  " + Datos.estudiantes[e]);
                cuantos++;
            }
        }
        if (cuantos == 0) {
            System.out.println("  Nadie");
        }
    }

    // Prueba las operaciones. A la derecha, lo que debe salir.
    public static void main(String[] args) {
        // Buscar estudiantes y días
        System.out.println("Brais está en la posición " + buscarEstudiante("Brais")); // 1
        System.out.println("noa está en la posición " + buscarEstudiante("noa"));     // 8
        System.out.println("Pepe está en la posición " + buscarEstudiante("Pepe"));   // -1
        System.out.println("X es el día " + buscarDia("X"));                          // 2
        System.out.println("S es el día " + buscarDia("S"));                          // -1

        // Poner ausencias
        System.out.println(ponerAusencia("Ana", "L"));   // true
        System.out.println(ponerAusencia("Iria", "L"));  // true
        System.out.println(ponerAusencia("Brais", "X")); // true
        System.out.println(ponerAusencia("Pepe", "L"));  // false: Pepe no está
        System.out.println(ponerAusencia("Ana", "S"));   // false: S no es un día

        // Imprimir ausentes
        imprimirAusentes("L"); // Ausentes el L:   Ana   Iria
        imprimirAusentes("X"); // Ausentes el X:   Brais
        imprimirAusentes("V"); // Ausentes el V:   Nadie
        imprimirAusentes("S"); // El día S no existe
    }
}
