package ausencias;

// Clase de datos: solo guarda la información, sin operaciones
public class Datos {

    // Los 10 estudiantes del grupo
    static String[] estudiantes = {"Ana", "Brais", "Carla", "Daniel", "Elena",
                                   "Fran", "Iria", "Lucas", "Noa", "Xoán"};

    // Los días de la semana, de lunes a viernes
    static String[] dias = {"L", "M", "X", "J", "V"};

    // Las ausencias de la semana: una fila por estudiante y una columna por día.
    // ausencias[e][d] es true si el estudiante de la posición e faltó el día d.
    // Al crearlo, todas las casillas valen false: nadie ha faltado.
    static boolean[][] ausencias = new boolean[estudiantes.length][dias.length];
}
