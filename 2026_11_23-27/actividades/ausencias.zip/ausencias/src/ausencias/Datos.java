package ausencias;

// Clase de datos: solo guarda la información, sin operaciones
public class Datos {

    // 1. Un array de String con los nombres de 10 estudiantes, declarado e inicializado
    //    con sus valores. Se llama estudiantes. Para que salga lo que espera el main
    //    de Operaciones: Ana, Brais, Carla, Daniel, Elena, Fran, Iria, Lucas, Noa y Xoán.
    // escribe aquí tu código


    // 2. Un array de String con los días de la semana, de lunes a viernes:
    //    "L", "M", "X", "J" y "V". Se llama dias.
    // escribe aquí tu código


    // 3. Un array de boolean de dos dimensiones con las ausencias de la semana:
    //    una fila por estudiante y una columna por día. Se llama ausencias.
    //    ausencias[e][d] es true si el estudiante de la posición e faltó el día d.
    //    Su tamaño sale de los otros dos arrays, sin escribir 10 ni 5 a mano.
    // escribe aquí tu código

}
