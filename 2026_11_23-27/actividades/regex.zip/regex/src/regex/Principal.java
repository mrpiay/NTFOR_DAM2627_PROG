package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.util.Arrays;

public class Principal {

    // Ejercicio 1: validar formatos con matches
    static void ejercicio1() {
        System.out.println("== Ejercicio 1: validar con matches ==");
        String[] codigos = {"28013", "2801", "28O13", "280135"};
        for (String c : codigos) {
            System.out.println(c + " es código postal: " + c.matches("\\d{5}"));
        }
        String[] dnis = {"12345678Z", "1234567Z", "12345678z"};
        for (String d : dnis) {
            System.out.println(d + " es DNI: " + d.matches("\\d{8}[A-Z]"));
        }
    }

    // Ejercicio 2: buscar DNI y códigos postales dentro de un texto
    static void ejercicio2() {
        System.out.println("== Ejercicio 2: buscar con Pattern y Matcher ==");
        String texto = "Ana García, DNI 12345678Z, vive en el 15001 (A Coruña). "
                     + "Luis Pérez, DNI 87654321x, vive en el 36201 (Vigo).";

        Pattern dni = Pattern.compile("\\d{8}[A-Z]", Pattern.CASE_INSENSITIVE);
        Matcher m = dni.matcher(texto);
        while (m.find()) {
            // Se guarda con la letra en mayúscula, como se escribe un DNI
            System.out.println("DNI encontrado: " + m.group().toUpperCase());
        }

        // \b: el código postal es un número suelto de 5 cifras, no un trozo del DNI
        Matcher cp = Pattern.compile("\\b\\d{5}\\b").matcher(texto);
        int cuantos = 0;
        while (cp.find()) {
            cuantos++;
            System.out.println("Código postal " + cuantos + ": " + cp.group());
        }
    }

    // Ejercicio 3 - repaso de arrays de 1 y 2 dimensiones
    static void ejercicio3(){
        // Crear tabla con 2 columnas y 3 filas de tipo int
        int [][] tabla = new int[3][2];

        // Poner toda la fila 0 a 0, toda la fila 1 a 1 y toda la fila 2 a 2
        for(int fila = 0; fila <=2; fila++)
            for(int col = 0; col <=1; col++ )
                //tabla[fila][col] = fila; //(0 0) (1 1) (2 2)
                //tabla[fila][col] = 2 - fila; //(2 2) (1 1) (0 0)
                tabla[fila][col] = col + 2 * fila; //(0 1) (2 3) (4 5)

        // Imprimir tabla
        for(int [] fila : tabla)
            System.out.println(Arrays.toString(fila));

        // Sumar la fila 1
        int total = 0;
        for(int dato : tabla[0])
            total = total + dato;
        System.out.println(total);

        total = 0;
        for(int col = 0; col < tabla[0].length; col++)
            total = total + tabla[0][col];
        System.out.println(total);

        // Sumar la columna 2
        total = 0;
        for(int fila = 0; fila < tabla.length; fila++)
            total = total + tabla[fila][1];
        System.out.println(total);

        // Sumar todos los valores de la tabla
        int totalTabla = 0;
        int totalFila;
        for(int[] fila : tabla){
            totalFila = 0;
            for(int dato : fila){
                totalFila = totalFila + dato;
            }
            totalTabla = totalTabla + totalFila;
        }
        System.out.println(totalTabla);
    }

    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        ejercicio3();
    }
}
