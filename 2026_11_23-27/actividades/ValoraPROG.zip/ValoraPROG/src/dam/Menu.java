package dam;

import java.util.Random;
import java.util.Scanner;

/**
 * El menú de ValoraPROG y lo que hace cada opción: todo lo que habla con la persona.
 * Lee con Scanner y escribe con println y printf; las cuentas las pide a Calculos.
 * Los datos (las notas, total y los pesos) los crea main, en Principal, y llegan como parámetros.
 */
public class Menu {

    // Las categorías que se valoran: una columna de la matriz de notas para cada una
    public static final String[] CATEGORIAS = {"Docente", "Materiales", "Clases"};

    // Cuántas valoraciones caben como máximo: el número de filas de la matriz
    public static final int MAX_VALORACIONES = 30;

    // Cuántas valoraciones crea de una vez la opción 5
    public static final int AL_AZAR = 10;

    // El formato de cada fila del resumen, para que las columnas queden alineadas como en una tabla:
    // %-12s, un texto en 12 caracteres pegado a la izquierda; %6s, en 6 pegado a la derecha;
    // %s, el texto tal cual; %n, el salto de línea.
    // Los números van con %s, no con %.1f: así salen con punto (4.5), como con println,
    // y no con coma (4,5) si el sistema está en español
    public static final String FILA = "  %-12s %6s  %-10s %5s  %s%n";

    // ── El menú ──────────────────────────────────────────────────────────
    public static void mostrarMenu() {
        System.out.println();
        System.out.println("=== ValoraPROG ===");
        System.out.println("1. Nueva valoración");
        System.out.println("2. Ver valoración global");
        System.out.println("3. Cambiar pesos");
        System.out.println("4. Ver la mejor valoración");
        System.out.println("5. Crear " + AL_AZAR + " valoraciones al azar");
        System.out.println("6. Modificar una valoración");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
    }

    // ── Leer un número ───────────────────────────────────────────────────
    // Pregunta hasta que se escribe un número entero entre minimo y maximo, y lo devuelve.
    // Sirve para las notas (del 1 al 5) y para los pesos (del 1 al 10)
    public static int leerEntero(Scanner teclado, String pregunta, int minimo, int maximo) {
        int numero = minimo - 1;    // empieza fuera del rango: así pregunta al menos una vez
        while (!Calculos.estaEntre(numero, minimo, maximo)) {
            System.out.print(pregunta + " (" + minimo + "-" + maximo + "): ");
            try {
                numero = Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                numero = minimo - 1;    // no es un número: se trata como uno fuera del rango
            }
            if (!Calculos.estaEntre(numero, minimo, maximo)) {
                System.out.println("  Escribe un número del " + minimo + " al " + maximo + ".");
            }
        }
        return numero;
    }

    // ── 1. Nueva valoración ──────────────────────────────────────────────
    // Pide una nota por categoría y la guarda en la fila que recibe.
    // La fila es un array y se recibe por referencia: lo que se guarda aquí, queda en la matriz de main
    public static void nuevaValoracion(Scanner teclado, int[] fila) {
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            fila[categoria] = leerEntero(teclado, CATEGORIAS[categoria], Calculos.NOTA_MINIMA, Calculos.NOTA_MAXIMA);
        }
    }

    // ── Las tablas ───────────────────────────────────────────────────────
    // La cabecera de una tabla, y debajo una línea de = tan larga como su texto.
    // Las tres primeras columnas son siempre las mismas; las dos últimas, las que se le pasan.
    // String.format hace lo mismo que printf, pero devuelve el texto en lugar de escribirlo;
    // trim le quita los espacios del principio y el salto de línea del final
    public static void escribirCabecera(String columna4, String columna5) {
        String cabecera = String.format(FILA, "Categoría", "Peso", "Estrellas", columna4, columna5);
        System.out.print(cabecera);
        System.out.println("  " + "=".repeat(cabecera.trim().length()));
    }

    // El peso de una categoría, en porcentaje y como texto: "33.3%"
    public static String peso(int[] pesos, int categoria) {
        return Calculos.redondear(Calculos.porcentaje(pesos, categoria)) + "%";
    }

    // ── 2. Ver valoración global ─────────────────────────────────────────
    // Las cuentas las hace Calculos; aquí solo se muestran
    public static void mostrarResumen(int[][] notas, int total, int[] pesos) {
        if (total == 0) {
            System.out.println("Aún no hay valoraciones.");
            return;
        }
        System.out.println("Valoraciones: " + total);
        System.out.println();
        escribirCabecera("Media", "Notas");
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            double media = Calculos.media(notas, total, categoria);
            System.out.printf(FILA, CATEGORIAS[categoria], peso(pesos, categoria), Calculos.estrellas(media),
                    Calculos.redondear(media), Calculos.unir(notas, total, categoria));
        }
        double global = Calculos.global(notas, total, pesos);
        System.out.printf(FILA, "Global", "", Calculos.estrellas(global), Calculos.redondear(global), "");
    }

    // ── 3. Cambiar los pesos ─────────────────────────────────────────────
    // Muestra los pesos de ahora y pide uno nuevo, del 1 al 10, para cada categoría.
    // Como la fila en nuevaValoracion, pesos es un array: lo que se cambia aquí, queda en el de main
    public static void cambiarPesos(Scanner teclado, int[] pesos) {
        System.out.println("Cuánto cuenta cada categoría en la valoración global. Pesos de ahora:");
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            System.out.println("  " + CATEGORIAS[categoria] + ": " + pesos[categoria]);
        }
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            pesos[categoria] = leerEntero(teclado, "Peso de " + CATEGORIAS[categoria],
                    Calculos.PESO_MINIMO, Calculos.PESO_MAXIMO);
        }
        System.out.println("Pesos guardados.");
    }

    // ── 4. Ver la mejor valoración ───────────────────────────────────────
    // La de nota global más alta, con los pesos de ahora. Si hay empate, la primera
    public static void mostrarMejor(int[][] notas, int total, int[] pesos) {
        if (total == 0) {
            System.out.println("Aún no hay valoraciones.");
            return;
        }
        int mejor = Calculos.mejor(notas, total, pesos);
        int[] fila = notas[mejor];
        // Las filas empiezan en 0, y las valoraciones se cuentan desde 1: la fila 0 es la n.º 1
        System.out.println("Mejor valoración: n.º " + (mejor + 1) + " de " + total);
        System.out.println();
        escribirCabecera("Nota", "");
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            System.out.printf(FILA, CATEGORIAS[categoria], peso(pesos, categoria),
                    Calculos.estrellas(fila[categoria]), fila[categoria], "");
        }
        double global = Calculos.globalDe(fila, pesos);
        System.out.printf(FILA, "Global", "", Calculos.estrellas(global), Calculos.redondear(global), "");
    }

    // ── 5. Crear valoraciones al azar ────────────────────────────────────
    // Rellena hasta AL_AZAR filas libres con notas al azar, sin pasar del máximo,
    // y devuelve cuántas ha creado: main las suma a total, porque total es un int.
    // Sirve para probar el programa con muchos datos sin escribirlos
    public static int crearAlAzar(int[][] notas, int total, Random azar) {
        int libres = MAX_VALORACIONES - total;
        int crear = Math.min(AL_AZAR, libres);      // la menor de las dos: 10, o las que quepan
        for (int i = 0; i < crear; i++) {
            int[] fila = notas[total + i];          // la siguiente fila libre
            for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
                // nextInt(desde, hasta) da un entero al azar desde «desde» hasta «hasta» SIN incluirlo:
                // por eso NOTA_MAXIMA + 1, para que el 5 pueda salir
                fila[categoria] = azar.nextInt(Calculos.NOTA_MINIMA, Calculos.NOTA_MAXIMA + 1);
            }
        }
        return crear;
    }

    // ── 6. Modificar una valoración ──────────────────────────────────────
    // Solo una que ya existe: se pide su número, del 1 a total. Muestra sus notas y las vuelve a pedir.
    // La valoración n.º X está en la fila X - 1, y se rellena con nuevaValoracion, igual que una nueva.
    // total no cambia: no se añade ninguna
    public static void modificarValoracion(Scanner teclado, int[][] notas, int total) {
        if (total == 0) {
            System.out.println("Aún no hay valoraciones.");
            return;
        }
        int numero = leerEntero(teclado, "Número de la valoración", 1, total);
        int[] fila = notas[numero - 1];
        System.out.println("Notas de ahora de la n.º " + numero + ":");
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            System.out.println("  " + CATEGORIAS[categoria] + ": " + fila[categoria]);
        }
        nuevaValoracion(teclado, fila);
        System.out.println("Valoración n.º " + numero + " modificada.");
    }
}
