package dam;

import java.util.Random;
import java.util.Scanner;

/**
 * ValoraPROG: valoraciones anónimas de docente, materiales y clases, con un menú en la terminal.
 * Las valoraciones y los pesos se guardan en memoria: al salir del programa, se pierden.
 *
 * Aquí solo está main: crea los datos y repite el menú. Lo que hace cada opción está en Menu,
 * y las cuentas, en Calculos.
 */
public class Principal {

    // ── El programa: el menú, que se repite hasta elegir 0 ───────────────
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Una fila por valoración y una columna por categoría:
        // notas[0][1] es la nota de «Materiales» (columna 1) de la primera valoración (fila 0)
        int[][] notas = new int[Menu.MAX_VALORACIONES][Menu.CATEGORIAS.length];
        int total = 0;      // cuántas valoraciones hay: las filas ya rellenas

        // Un peso por categoría, en el mismo orden que CATEGORIAS. Al empezar, todas cuentan lo mismo
        int[] pesos = {1, 1, 1};

        // El generador de números al azar de la opción 5: uno para todo el programa
        Random azar = new Random();

        String opcion;
        do {
            Menu.mostrarMenu();
            opcion = teclado.nextLine().trim();     // trim quita los espacios de los extremos
            System.out.println();                   // una línea en blanco entre el menú y la respuesta

            switch (opcion) {
                case "1" -> {
                    if (total == Menu.MAX_VALORACIONES) {
                        System.out.println("No caben más valoraciones: el máximo es " + Menu.MAX_VALORACIONES + ".");
                    } else {
                        Menu.nuevaValoracion(teclado, notas[total]);   // rellena la primera fila libre
                        total++;                                       // total es un int: se cambia aquí, en main
                        System.out.println("Valoración guardada (" + total + " en total).");
                    }
                }
                case "2" -> Menu.mostrarResumen(notas, total, pesos);
                case "3" -> Menu.cambiarPesos(teclado, pesos);
                case "4" -> Menu.mostrarMejor(notas, total, pesos);
                case "5" -> {
                    int creadas = Menu.crearAlAzar(notas, total, azar);
                    total += creadas;                                  // como en la opción 1: total se cambia en main
                    if (creadas == 0) {
                        System.out.println("No caben más valoraciones: el máximo es " + Menu.MAX_VALORACIONES + ".");
                    } else {
                        System.out.println(creadas + " valoraciones creadas al azar (" + total + " en total).");
                    }
                }
                case "6" -> Menu.modificarValoracion(teclado, notas, total);
                case "0" -> System.out.println("Hasta pronto. Las valoraciones y los pesos no se guardan al salir.");
                default -> System.out.println("Opción no válida: elige una del menú.");
            }
        } while (!opcion.equals("0"));

        teclado.close();
    }
}
