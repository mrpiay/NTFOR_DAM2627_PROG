package dam;

import java.util.Scanner;

/**
 * ValoraPROG: valoraciones anónimas de docente, materiales y clases, con un menú en la terminal.
 * Las valoraciones se guardan en memoria: al salir del programa, se pierden.
 */
public class Principal {

    // Las categorías que se valoran: una columna de la matriz de notas para cada una
    static final String[] CATEGORIAS = {"Docente", "Materiales", "Clases"};

    // Cuántas valoraciones caben como máximo: el número de filas de la matriz
    static final int MAX_VALORACIONES = 30;

    // ── El programa: el menú, que se repite hasta elegir 0 ───────────────
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Una fila por valoración y una columna por categoría:
        // notas[0][1] es la nota de «Materiales» (columna 1) de la primera valoración (fila 0)
        int[][] notas = new int[MAX_VALORACIONES][CATEGORIAS.length];
        int total = 0;      // cuántas valoraciones hay: las filas ya rellenas

        String opcion;
        do {
            mostrarMenu();
            opcion = teclado.nextLine().trim();     // trim quita los espacios de los extremos
            System.out.println();                   // una línea en blanco entre el menú y la respuesta

            switch (opcion) {
                case "1" -> {
                    if (total == MAX_VALORACIONES) {
                        System.out.println("No caben más valoraciones: el máximo es " + MAX_VALORACIONES + ".");
                    } else {
                        nuevaValoracion(teclado, notas[total]);    // rellena la primera fila libre
                        total++;                                   // total es un int: se cambia aquí, en main
                        System.out.println("Valoración guardada (" + total + " en total).");
                    }
                }
                case "2" -> mostrarResumen(notas, total);
                case "0" -> System.out.println("Hasta pronto. Las valoraciones no se guardan al salir.");
                default -> System.out.println("Opción no válida: escribe 1, 2 o 0.");
            }
        } while (!opcion.equals("0"));

        teclado.close();
    }

    // ── El menú ──────────────────────────────────────────────────────────
    static void mostrarMenu() {
        System.out.println();
        System.out.println("=== ValoraPROG ===");
        System.out.println("1. Nueva valoración");
        System.out.println("2. Ver valoración global");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
    }

    // ── 1. Nueva valoración ──────────────────────────────────────────────
    // Pide una nota por categoría y la guarda en la fila que recibe.
    // La fila es un array y se recibe por referencia: lo que se guarda aquí, queda en la matriz de main
    static void nuevaValoracion(Scanner teclado, int[] fila) {
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            fila[categoria] = leerNota(teclado, CATEGORIAS[categoria]);
        }
    }

    // Pregunta la nota de una categoría hasta que sea un número del 1 al 5, y la devuelve
    static int leerNota(Scanner teclado, String categoria) {
        int nota = 0;
        while (!Calculos.esNotaValida(nota)) {
            System.out.print(categoria + " (1-5): ");
            try {
                nota = Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                nota = 0;   // no es un número: se trata como una nota no válida
            }
            if (!Calculos.esNotaValida(nota)) {
                System.out.println("  Escribe un número del 1 al 5.");
            }
        }
        return nota;
    }

    // ── 2. Ver valoración global ─────────────────────────────────────────
    // Las cuentas las hace Calculos; aquí solo se muestran
    static void mostrarResumen(int[][] notas, int total) {
        if (total == 0) {
            System.out.println("Aún no hay valoraciones.");
            return;
        }
        System.out.println("Valoraciones: " + total);
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            String lista = Calculos.unir(notas, total, categoria);
            double media = Calculos.media(notas, total, categoria);
            String estrellas = Calculos.estrellas(media);
            System.out.println("  " + CATEGORIAS[categoria] + ": " + estrellas + "  " + lista + " (media " + Calculos.redondear(media) + ")");
        }
        double global = Calculos.global(notas, total);
        System.out.println("Valoración global: " + Calculos.estrellas(global) + "  " + Calculos.redondear(global));
    }
}
