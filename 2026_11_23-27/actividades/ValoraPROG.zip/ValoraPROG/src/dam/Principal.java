package dam;

import java.util.Scanner;

/**
 * ValoraPROG: valoraciones anónimas de docente, materiales y clases, con un menú en la terminal.
 * Las valoraciones y los pesos se guardan en memoria: al salir del programa, se pierden.
 */
public class Principal {

    // Las categorías que se valoran: una columna de la matriz de notas para cada una
    static final String[] CATEGORIAS = {"Docente", "Materiales", "Clases"};

    // Cuántas valoraciones caben como máximo: el número de filas de la matriz
    static final int MAX_VALORACIONES = 30;

    // El formato de cada fila del resumen, para que las columnas queden alineadas como en una tabla:
    // %-12s, un texto en 12 caracteres pegado a la izquierda; %6s, en 6 pegado a la derecha;
    // %s, el texto tal cual; %n, el salto de línea.
    // Los números van con %s, no con %.1f: así salen con punto (4.5), como con println,
    // y no con coma (4,5) si el sistema está en español
    static final String FILA = "  %-12s %6s  %-10s %5s  %s%n";

    // ── El programa: el menú, que se repite hasta elegir 0 ───────────────
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Una fila por valoración y una columna por categoría:
        // notas[0][1] es la nota de «Materiales» (columna 1) de la primera valoración (fila 0)
        int[][] notas = new int[MAX_VALORACIONES][CATEGORIAS.length];
        int total = 0;      // cuántas valoraciones hay: las filas ya rellenas

        // Un peso por categoría, en el mismo orden que CATEGORIAS. Al empezar, todas cuentan lo mismo
        int[] pesos = {1, 1, 1};

        String opcion;
        do {
            mostrarMenu();
            opcion = teclado.nextLine().trim();     // trim quita los espacios de los extremos
            System.out.println();                   // una línea en blanco entre el menú y la respuesta

            switch (opcion) {
                case "1" -> {
                    if (total == MAX_VALORACIONES) {
                        System.out.println("No caben más valoraciones: el máximo es " + MAX_VALORACIONES + ".");
                    } else {
                        nuevaValoracion(teclado, notas[total]);    // rellena la primera fila libre
                        total++;                                   // total es un int: se cambia aquí, en main
                        System.out.println("Valoración guardada (" + total + " en total).");
                    }
                }
                case "2" -> mostrarResumen(notas, total, pesos);
                case "3" -> cambiarPesos(teclado, pesos);
                case "0" -> System.out.println("Hasta pronto. Las valoraciones y los pesos no se guardan al salir.");
                default -> System.out.println("Opción no válida: escribe 1, 2, 3 o 0.");
            }
        } while (!opcion.equals("0"));

        teclado.close();
    }

    // ── El menú ──────────────────────────────────────────────────────────
    static void mostrarMenu() {
        System.out.println();
        System.out.println("=== ValoraPROG ===");
        System.out.println("1. Nueva valoración");
        System.out.println("2. Ver valoración global");
        System.out.println("3. Cambiar pesos");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
    }

    // ── Leer un número ───────────────────────────────────────────────────
    // Pregunta hasta que se escribe un número entero entre minimo y maximo, y lo devuelve.
    // Sirve para las notas (del 1 al 5) y para los pesos (del 1 al 10)
    static int leerEntero(Scanner teclado, String pregunta, int minimo, int maximo) {
        int numero = minimo - 1;    // empieza fuera del rango: así pregunta al menos una vez
        while (!Calculos.estaEntre(numero, minimo, maximo)) {
            System.out.print(pregunta + " (" + minimo + "-" + maximo + "): ");
            try {
                numero = Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                numero = minimo - 1;    // no es un número: se trata como uno fuera del rango
            }
            if (!Calculos.estaEntre(numero, minimo, maximo)) {
                System.out.println("  Escribe un número del " + minimo + " al " + maximo + ".");
            }
        }
        return numero;
    }

    // ── 1. Nueva valoración ──────────────────────────────────────────────
    // Pide una nota por categoría y la guarda en la fila que recibe.
    // La fila es un array y se recibe por referencia: lo que se guarda aquí, queda en la matriz de main
    static void nuevaValoracion(Scanner teclado, int[] fila) {
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            fila[categoria] = leerEntero(teclado, CATEGORIAS[categoria], Calculos.NOTA_MINIMA, Calculos.NOTA_MAXIMA);
        }
    }

    // ── 2. Ver valoración global ─────────────────────────────────────────
    // Las cuentas las hace Calculos; aquí solo se muestran
    static void mostrarResumen(int[][] notas, int total, int[] pesos) {
        if (total == 0) {
            System.out.println("Aún no hay valoraciones.");
            return;
        }
        System.out.println("Valoraciones: " + total);
        System.out.println();
        // La cabecera, y debajo una línea de = tan larga como su texto.
        // String.format hace lo mismo que printf, pero devuelve el texto en lugar de escribirlo;
        // trim le quita los espacios del principio y el salto de línea del final
        String cabecera = String.format(FILA, "Categoría", "Peso", "Estrellas", "Media", "Notas");
        System.out.print(cabecera);
        System.out.println("  " + "=".repeat(cabecera.trim().length()));
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            double media = Calculos.media(notas, total, categoria);
            String peso = Calculos.redondear(Calculos.porcentaje(pesos, categoria)) + "%";
            System.out.printf(FILA, CATEGORIAS[categoria], peso, Calculos.estrellas(media),
                    Calculos.redondear(media), Calculos.unir(notas, total, categoria));
        }
        double global = Calculos.global(notas, total, pesos);
        System.out.printf(FILA, "Global", "", Calculos.estrellas(global), Calculos.redondear(global), "");
    }

    // ── 3. Cambiar los pesos ─────────────────────────────────────────────
    // Muestra los pesos de ahora y pide uno nuevo, del 1 al 10, para cada categoría.
    // Como la fila en nuevaValoracion, pesos es un array: lo que se cambia aquí, queda en el de main
    static void cambiarPesos(Scanner teclado, int[] pesos) {
        System.out.println("Cuánto cuenta cada categoría en la valoración global. Pesos de ahora:");
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            System.out.println("  " + CATEGORIAS[categoria] + ": " + pesos[categoria]);
        }
        for (int categoria = 0; categoria < CATEGORIAS.length; categoria++) {
            pesos[categoria] = leerEntero(teclado, "Peso de " + CATEGORIAS[categoria],
                    Calculos.PESO_MINIMO, Calculos.PESO_MAXIMO);
        }
        System.out.println("Pesos guardados.");
    }
}
