package dam;

/**
 * Los cálculos de ValoraPROG.
 * Aquí no hay Scanner ni println: solo cuentas. Las usa Principal.
 *
 * Las notas están en una matriz: una fila por valoración y una columna por categoría.
 * Solo cuentan las primeras «total» filas: las demás aún están vacías.
 * Los pesos están en un array: uno por categoría, en el mismo orden que las columnas.
 */
public class Calculos {

    // ── Los límites: las notas van de 1 a 5, y los pesos, de 1 a 10 ──────
    public static final int NOTA_MINIMA = 1;
    public static final int NOTA_MAXIMA = 5;
    public static final int PESO_MINIMO = 1;
    public static final int PESO_MAXIMO = 10;

    // ¿Está el número entre minimo y maximo, los dos incluidos?
    public static boolean estaEntre(int numero, int minimo, int maximo) {
        return numero >= minimo && numero <= maximo;
    }

    // ── Las notas de una categoría, como texto: "4, 5, 3" ────────────────
    public static String unir(int[][] notas, int total, int categoria) {
        String texto = "";
        for (int fila = 0; fila < total; fila++) {
            if (fila > 0) {
                texto += ", ";      // la coma va antes de cada nota, menos de la primera
            }
            texto += notas[fila][categoria];
        }
        return texto;
    }

    // ── Las medias ───────────────────────────────────────────────────────
    // La media de una categoría: la suma de su columna entre el número de valoraciones.
    // (double) evita la división entera: 7 / 2 da 3, pero (double) 7 / 2 da 3.5
    public static double media(int[][] notas, int total, int categoria) {
        int suma = 0;
        for (int fila = 0; fila < total; fila++) {
            suma += notas[fila][categoria];
        }
        return (double) suma / total;
    }

    // ── Los pesos ────────────────────────────────────────────────────────
    // La suma de todos los pesos
    public static int sumaPesos(int[] pesos) {
        int suma = 0;
        for (int categoria = 0; categoria < pesos.length; categoria++) {
            suma += pesos[categoria];
        }
        return suma;
    }

    // Lo que cuenta una categoría en la valoración global, en porcentaje:
    // con pesos 2, 1 y 1, la primera cuenta el 50 % (2 de 4) y cada una de las otras, el 25 %
    public static double porcentaje(int[] pesos, int categoria) {
        return 100.0 * pesos[categoria] / sumaPesos(pesos);
    }

    // La valoración global, ponderada: cada media multiplicada por su peso, todo sumado,
    // y dividido entre la suma de los pesos.
    // Con todos los pesos iguales, es la media de las medias
    public static double global(int[][] notas, int total, int[] pesos) {
        double sumaPonderada = 0;
        for (int categoria = 0; categoria < pesos.length; categoria++) {
            sumaPonderada += media(notas, total, categoria) * pesos[categoria];
        }
        return sumaPonderada / sumaPesos(pesos);
    }

    // ── La mejor valoración ──────────────────────────────────────────────
    // La nota global de una sola valoración: sus notas, ponderadas con los pesos.
    // fila es una fila de la matriz: las notas de esa valoración
    public static double globalDe(int[] fila, int[] pesos) {
        int sumaPonderada = 0;
        for (int categoria = 0; categoria < pesos.length; categoria++) {
            sumaPonderada += fila[categoria] * pesos[categoria];
        }
        return (double) sumaPonderada / sumaPesos(pesos);
    }

    // La fila de la mejor valoración: la de nota global más alta.
    // Empieza suponiendo que es la primera (fila 0) y la compara con cada una de las demás.
    // Si hay empate, se queda con la primera: solo cambia con una mayor (>), no con una igual
    public static int mejor(int[][] notas, int total, int[] pesos) {
        int mejorFila = 0;
        for (int fila = 1; fila < total; fila++) {
            if (globalDe(notas[fila], pesos) > globalDe(notas[mejorFila], pesos)) {
                mejorFila = fila;
            }
        }
        return mejorFila;
    }

    // ── La mejor nota de cada categoría ──────────────────────────────────
    // La nota más alta de una categoría: el máximo de su columna.
    // Empieza suponiendo que es la de la fila 0 y la compara con cada una de las demás
    public static int maxima(int[][] notas, int total, int categoria) {
        int maxima = notas[0][categoria];
        for (int fila = 1; fila < total; fila++) {
            if (notas[fila][categoria] > maxima) {
                maxima = notas[fila][categoria];
            }
        }
        return maxima;
    }

    // Los números de las valoraciones que tienen esa nota en esa categoría, como texto: "2, 7, 9".
    // Las filas empiezan en 0 y las valoraciones se cuentan desde 1: por eso fila + 1
    public static String conNota(int[][] notas, int total, int categoria, int nota) {
        String texto = "";
        for (int fila = 0; fila < total; fila++) {
            if (notas[fila][categoria] == nota) {
                if (!texto.isEmpty()) {
                    texto += ", ";      // la coma va antes de cada número, menos del primero
                }
                texto += (fila + 1);    // con paréntesis: primero se suma, y después se añade al texto
            }
        }
        return texto;
    }

    // ── Redondear para mostrar ───────────────────────────────────────────
    // Redondea a un decimal: 3.8333 → 3.8, y 3.85 → 3.9
    public static double redondear(double numero) {
        return Math.round(numero * 10) / 10.0;
    }

    // ── Las estrellas: la media, de un vistazo ───────────────────────────
    // Un * por cada estrella y un - por cada una que falta, hasta 5: 3.8 → "****-"
    // Las estrellas son la media redondeada a un entero: 4.5 → 5, 3.8 → 4, 2.0 → 2.
    // Antes se redondea a un decimal, como se muestra, para que las estrellas
    // y el número coincidan: 4.46 se muestra 4.5, y da 5 estrellas, no 4
    public static String estrellas(double media) {
        int llenas = (int) Math.round(redondear(media));   // Math.round devuelve un long: (int) lo pasa a int
        String texto = "";
        for (int estrella = NOTA_MINIMA; estrella <= NOTA_MAXIMA; estrella++) {
            if (estrella <= llenas) {
                texto += "*";
            } else {
                texto += "-";
            }
        }
        return texto;
    }
}
