package dam;

/**
 * Los cálculos de ValoraPROG.
 * Aquí no hay Scanner ni println: solo cuentas. Las usa Principal.
 *
 * Las notas están en una matriz: una fila por valoración y una columna por categoría.
 * Solo cuentan las primeras «total» filas: las demás aún están vacías.
 */
public class Calculos {

    // ── Las notas válidas van de 1 a 5 ───────────────────────────────────
    public static final int NOTA_MINIMA = 1;
    public static final int NOTA_MAXIMA = 5;

    // ¿Está la nota entre 1 y 5?
    public static boolean esNotaValida(int nota) {
        return nota >= NOTA_MINIMA && nota <= NOTA_MAXIMA;
    }

    // ── Las notas de una categoría, como texto: "4, 5, 3" ────────────────
    public static String unir(int[][] notas, int total, int categoria) {
        String texto = "";
        for (int fila = 0; fila < total; fila++) {
            if (fila > 0) {
                texto += ", ";      // la coma va antes de cada nota, menos de la primera
            }
            texto += notas[fila][categoria];
        }
        return texto;
    }

    // ── Las medias ───────────────────────────────────────────────────────
    // La media de una categoría: la suma de su columna entre el número de valoraciones.
    // (double) evita la división entera: 7 / 2 da 3, pero (double) 7 / 2 da 3.5
    public static double media(int[][] notas, int total, int categoria) {
        int suma = 0;
        for (int fila = 0; fila < total; fila++) {
            suma += notas[fila][categoria];
        }
        return (double) suma / total;
    }

    // La valoración global, con pesos iguales: la media de las medias de las categorías.
    // notas[0].length es el número de columnas: el de categorías
    public static double global(int[][] notas, int total) {
        int categorias = notas[0].length;
        double sumaMedias = 0;
        for (int categoria = 0; categoria < categorias; categoria++) {
            sumaMedias += media(notas, total, categoria);
        }
        return sumaMedias / categorias;
    }

    // ── Redondear para mostrar ───────────────────────────────────────────
    // Redondea a un decimal: 3.8333 → 3.8, y 3.85 → 3.9
    public static double redondear(double numero) {
        return Math.round(numero * 10) / 10.0;
    }
}
