package dam;

/**
 * Los cálculos de ValoraPROG.
 * Aquí no hay Scanner ni println: solo cuentas. Las usa Principal.
 *
 * Las notas están en una matriz: una fila por valoración y una columna por categoría.
 * Solo cuentan las primeras «total» filas: las demás aún están vacías.
 * Los pesos están en un array: uno por categoría, en el mismo orden que las columnas.
 */
public class Calculos {

    // ── Los límites: las notas van de 1 a 5, y los pesos, de 1 a 10 ──────
    public static final int NOTA_MINIMA = 1;
    public static final int NOTA_MAXIMA = 5;
    public static final int PESO_MINIMO = 1;
    public static final int PESO_MAXIMO = 10;

    // ¿Está el número entre minimo y maximo, los dos incluidos?
    public static boolean estaEntre(int numero, int minimo, int maximo) {
        return numero >= minimo && numero <= maximo;
    }

    // ── Las notas de una categoría, como texto: "4, 5, 3" ────────────────
    public static String unir(int[][] notas, int total, int categoria) {
        String texto = "";
        for (int fila = 0; fila < total; fila++) {
            if (fila > 0) {
                texto += ", ";      // la coma va antes de cada nota, menos de la primera
            }
            texto += notas[fila][categoria];
        }
        return texto;
    }

    // ── Las medias ───────────────────────────────────────────────────────
    // La media de una categoría: la suma de su columna entre el número de valoraciones.
    // (double) evita la división entera: 7 / 2 da 3, pero (double) 7 / 2 da 3.5
    public static double media(int[][] notas, int total, int categoria) {
        int suma = 0;
        for (int fila = 0; fila < total; fila++) {
            suma += notas[fila][categoria];
        }
        return (double) suma / total;
    }

    // ── Los pesos ────────────────────────────────────────────────────────
    // La suma de todos los pesos
    public static int sumaPesos(int[] pesos) {
        int suma = 0;
        for (int categoria = 0; categoria < pesos.length; categoria++) {
            suma += pesos[categoria];
        }
        return suma;
    }

    // Lo que cuenta una categoría en la valoración global, en porcentaje:
    // con pesos 2, 1 y 1, la primera cuenta el 50 % (2 de 4) y cada una de las otras, el 25 %
    public static double porcentaje(int[] pesos, int categoria) {
        return 100.0 * pesos[categoria] / sumaPesos(pesos);
    }

    // La valoración global, ponderada: cada media multiplicada por su peso, todo sumado,
    // y dividido entre la suma de los pesos.
    // Con todos los pesos iguales, es la media de las medias
    public static double global(int[][] notas, int total, int[] pesos) {
        double sumaPonderada = 0;
        for (int categoria = 0; categoria < pesos.length; categoria++) {
            sumaPonderada += media(notas, total, categoria) * pesos[categoria];
        }
        return sumaPonderada / sumaPesos(pesos);
    }

    // ── Redondear para mostrar ───────────────────────────────────────────
    // Redondea a un decimal: 3.8333 → 3.8, y 3.85 → 3.9
    public static double redondear(double numero) {
        return Math.round(numero * 10) / 10.0;
    }

    // ── Las estrellas: la media, de un vistazo ───────────────────────────
    // Un * por cada estrella y un - por cada una que falta, hasta 5: 3.8 → "****-"
    // Las estrellas son la media redondeada a un entero: 4.5 → 5, 3.8 → 4, 2.0 → 2.
    // Antes se redondea a un decimal, como se muestra, para que las estrellas
    // y el número coincidan: 4.46 se muestra 4.5, y da 5 estrellas, no 4
    public static String estrellas(double media) {
        int llenas = (int) Math.round(redondear(media));   // Math.round devuelve un long: (int) lo pasa a int
        String texto = "";
        for (int estrella = NOTA_MINIMA; estrella <= NOTA_MAXIMA; estrella++) {
            if (estrella <= llenas) {
                texto += "*";
            } else {
                texto += "-";
            }
        }
        return texto;
    }
}
